class HomesController < ApplicationController
  def top
    @list = List.new
  end
end